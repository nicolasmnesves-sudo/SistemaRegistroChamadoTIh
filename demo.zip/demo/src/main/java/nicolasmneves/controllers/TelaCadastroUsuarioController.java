package nicolasmneves.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import nicolasmneves.Main;
import nicolasmneves.dao.UsuarioDAO;

public class TelaCadastroUsuarioController {

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtUsuario;

    @FXML
    private TextField txtSenha;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Label lblLogin;

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @FXML
    private void cadastrarOnClick() {

        String nome = txtNome.getText().trim();
        String usuario = txtUsuario.getText().trim();
        String senha = txtSenha.getText().trim();

        // Regra: não permitir campos vazios
        if (nome.isEmpty() || usuario.isEmpty() || senha.isEmpty()) {
            exibirAlerta(Alert.AlertType.WARNING, "Campos obrigatórios", "Preencha nome, usuário e senha antes de cadastrar.");
            return;
        }

        // Regra: não permitir usuário repetido
        if (usuarioDAO.usuarioExiste(usuario)) {
            exibirAlerta(Alert.AlertType.WARNING, "Usuário já existe", "Já existe um usuário cadastrado com esse login. Escolha outro.");
            return;
        }

        try {
            usuarioDAO.cadastrar(nome, usuario, senha);
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Usuário cadastrado com sucesso!");

            // Após cadastrar, redirecionar para a TelaLogin
            Main.trocarTela("TelaLogin.fxml", "Sistema de Chamados - Login");

        } catch (Exception e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Não foi possível cadastrar o usuário: " + e.getMessage());
        }
    }

    @FXML
    private void irParaLoginOnClick() {
        Main.trocarTela("TelaLogin.fxml", "Sistema de Chamados - Login");
    }

    private void exibirAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }
}
