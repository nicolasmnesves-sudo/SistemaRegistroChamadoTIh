package nicolasmneves.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import nicolasmneves.Main;
import nicolasmneves.dao.UsuarioDAO;

public class TelaLoginController {

    @FXML
    private TextField txtUsuario;

    @FXML
    private TextField txtSenha;

    @FXML
    private Button btnEntrar;

    @FXML
    private Label lblCadastro;

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @FXML
    private void entrarOnClick() {

        String usuario = txtUsuario.getText().trim();
        String senha = txtSenha.getText().trim();

        if (usuario.isEmpty() || senha.isEmpty()) {
            exibirAlerta(Alert.AlertType.WARNING, "Campos obrigatórios", "Informe usuário e senha.");
            return;
        }

        try {
            boolean autenticado = usuarioDAO.autenticar(usuario, senha);

            if (autenticado) {
                // Login correto: abrir TelaCadastroChamado
                Main.trocarTela("TelaCadastroChamado.fxml", "Sistema de Chamados - Registro de Chamado");
            } else {
                // Login incorreto: exibir mensagem
                exibirAlerta(Alert.AlertType.ERROR, "Falha no login", "Usuário ou senha incorretos");
            }

        } catch (Exception e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Não foi possível efetuar o login: " + e.getMessage());
        }
    }

    @FXML
    private void irParaCadastroOnClick() {
        Main.trocarTela("TelaCadastroUsuario.fxml", "Sistema de Chamados - Cadastro de Usuário");
    }

    private void exibirAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }
}
