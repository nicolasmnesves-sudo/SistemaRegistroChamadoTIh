package nicolasmneves.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe responsável por abrir a conexão com o banco de dados MySQL.
 * Ajuste USER e PASSWORD conforme a configuração do seu MySQL local.
 */
public class Conexao {

    private static final String URL =
            "jdbc:mysql://localhost:3306/sistema_chamados_ti?useTimezone=true&serverTimezone=UTC";

    private static final String USER = "root";

    private static final String PASSWORD = "";

    public static Connection conectar() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao conectar ao banco: " + e.getMessage(), e);
        }
    }
}
