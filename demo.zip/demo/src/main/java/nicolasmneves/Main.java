package nicolasmneves;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Classe principal da aplicação.
 * Responsável por abrir a janela inicial (Cadastro de Usuário)
 * e por trocar de tela sempre que necessário.
 */
public class Main extends Application {

    private static Stage stagePrincipal;

    @Override
    public void start(Stage stage) {
        stagePrincipal = stage;
        trocarTela("TelaCadastroUsuario.fxml", "Sistema de Chamados - Cadastro de Usuário");
    }

    /**
     * Troca a tela atualmente exibida na janela principal.
     *
     * @param fxml   nome do arquivo FXML (deve estar no pacote nicolasmneves)
     * @param titulo título exibido na barra da janela
     */
    public static void trocarTela(String fxml, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource(fxml));
            Parent root = loader.load();

            stagePrincipal.setScene(new Scene(root));
            stagePrincipal.setTitle(titulo);
            stagePrincipal.centerOnScreen();
            stagePrincipal.show();

        } catch (IOException e) {
            throw new RuntimeException("Erro ao carregar tela " + fxml + ": " + e.getMessage(), e);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
