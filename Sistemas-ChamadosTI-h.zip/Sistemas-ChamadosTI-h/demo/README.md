# Sistema de Registro de Chamados de TI (JavaFX)




## O que foi feito

Projeto Maven reorganizado no pacote `nicolasmneves`:

```
src/main/java/nicolasmneves/
├── Main.java                              -> ponto de entrada, troca de telas
├── conexao/Conexao.java                   -> conexão com sistema_chamados_ti
├── model/Usuario.java, Chamado.java
├── dao/UsuarioDAO.java                    -> cadastrar, usuarioExiste, autenticar
├── dao/ChamadoDAO.java                    -> registrar, listarAbertos (desafio extra)
└── controllers/
    ├── TelaCadastroUsuarioController.java
    ├── TelaLoginController.java
    └── TelaCadastroChamadoController.java

src/main/resources/nicolasmneves/
├── TelaCadastroUsuario.fxml
├── TelaLogin.fxml
└── TelaCadastroChamado.fxml

sql/script_sistema_chamados.sql
```

Todas as regras do enunciado foram implementadas:

- **TelaCadastroUsuario**: não permite campos vazios, não permite usuário repetido, redireciona para o login após cadastrar.
- **TelaLogin**: login correto abre a tela de chamados; login incorreto mostra "Usuário ou senha incorretos".
- **TelaCadastroChamado**: valida solicitante, equipamento, problema e prioridade individualmente; `cmbPrioridade` com Baixa/Média/Alta/Urgente; exibe MessageBox de sucesso e limpa os campos após registrar.
- **Desafio extra**: botão "Listar Chamados Abertos" que executa `SELECT * FROM chamados WHERE status_chamado = 'Aberto'` e mostra o resultado numa lista.

## Como rodar

1. **Banco de dados**: abra o MySQL Workbench e execute `sql/script_sistema_chamados.sql`.
2. **Conexão**: se seu MySQL tiver senha ou porta diferente, ajuste em `src/main/java/nicolasmneves/conexao/Conexao.java`.
3. **Rodar o projeto**:
   ```
   mvn clean javafx:run
   ```
   (ou rode a classe `nicolasmneves.Main` pela sua IDE, com o plugin JavaFX configurado).

## Teste obrigatório

Depois de cadastrar usuário, fazer login e registrar chamados pelo sistema, no MySQL Workbench:

```sql
USE sistema_chamados_ti;
SELECT * FROM usuarios;
SELECT * FROM chamados;
```
