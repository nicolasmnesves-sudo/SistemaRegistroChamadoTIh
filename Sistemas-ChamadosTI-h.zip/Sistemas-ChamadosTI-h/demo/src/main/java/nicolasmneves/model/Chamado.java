package nicolasmneves.model;

public class Chamado {

    private int id;
    private String solicitante;
    private String equipamento;
    private String problema;
    private String prioridade;
    private String statusChamado;
    private String dataAbertura;

    public Chamado() {
    }

    public Chamado(String solicitante, String equipamento, String problema, String prioridade) {
        this.solicitante = solicitante;
        this.equipamento = equipamento;
        this.problema = problema;
        this.prioridade = prioridade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSolicitante() {
        return solicitante;
    }

    public void setSolicitante(String solicitante) {
        this.solicitante = solicitante;
    }

    public String getEquipamento() {
        return equipamento;
    }

    public void setEquipamento(String equipamento) {
        this.equipamento = equipamento;
    }

    public String getProblema() {
        return problema;
    }

    public void setProblema(String problema) {
        this.problema = problema;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    public String getStatusChamado() {
        return statusChamado;
    }

    public void setStatusChamado(String statusChamado) {
        this.statusChamado = statusChamado;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    @Override
    public String toString() {
        return "#" + id + " | " + solicitante + " | " + equipamento + " | " + problema
                + " | Prioridade: " + prioridade + " | Status: " + statusChamado;
    }
}
