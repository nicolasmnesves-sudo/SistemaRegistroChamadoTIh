package nicolasmneves.controllers;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import nicolasmneves.dao.ChamadoDAO;
import nicolasmneves.model.Chamado;

import java.util.List;

public class TelaCadastroChamadoController {

    @FXML
    private TextField txtSolicitante;

    @FXML
    private TextField txtEquipamento;

    @FXML
    private TextField txtProblema;

    @FXML
    private ComboBox<String> cmbPrioridade;

    @FXML
    private Button btnRegistrarChamado;

    @FXML
    private Button btnLimpar;

    // Desafio extra: listar apenas chamados com status "Aberto"
    @FXML
    private Button btnListarAbertos;

    @FXML
    private ListView<String> lstChamadosAbertos;

    private final ChamadoDAO chamadoDAO = new ChamadoDAO();

    @FXML
    private void initialize() {
        cmbPrioridade.setItems(FXCollections.observableArrayList("Baixa", "Média", "Alta", "Urgente"));
    }

    @FXML
    private void registrarChamadoOnClick() {

        String solicitante = txtSolicitante.getText().trim();
        String equipamento = txtEquipamento.getText().trim();
        String problema = txtProblema.getText().trim();
        String prioridade = cmbPrioridade.getValue();

        // Regras obrigatórias: nenhum campo pode ficar vazio
        if (solicitante.isEmpty()) {
            exibirAlerta(Alert.AlertType.WARNING, "Campo obrigatório", "Informe o solicitante.");
            return;
        }
        if (equipamento.isEmpty()) {
            exibirAlerta(Alert.AlertType.WARNING, "Campo obrigatório", "Informe o equipamento.");
            return;
        }
        if (problema.isEmpty()) {
            exibirAlerta(Alert.AlertType.WARNING, "Campo obrigatório", "Informe o problema.");
            return;
        }
        if (prioridade == null || prioridade.isEmpty()) {
            exibirAlerta(Alert.AlertType.WARNING, "Campo obrigatório", "Selecione a prioridade.");
            return;
        }

        try {
            Chamado chamado = new Chamado(solicitante, equipamento, problema, prioridade);
            chamadoDAO.registrar(chamado);

            // Após registrar, exibir MessageBox de sucesso
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Chamado registrado com sucesso!");

            // Após registrar, limpar os campos
            limparCamposOnClick();

        } catch (Exception e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Não foi possível registrar o chamado: " + e.getMessage());
        }
    }

    @FXML
    private void limparCamposOnClick() {
        txtSolicitante.clear();
        txtEquipamento.clear();
        txtProblema.clear();
        cmbPrioridade.setValue(null);
    }

    /**
     * Desafio extra: lista no ListView apenas os chamados com status "Aberto".
     */
    @FXML
    private void listarAbertosOnClick() {
        try {
            List<Chamado> abertos = chamadoDAO.listarAbertos();

            lstChamadosAbertos.getItems().clear();

            if (abertos.isEmpty()) {
                lstChamadosAbertos.getItems().add("Nenhum chamado em aberto no momento.");
            } else {
                for (Chamado chamado : abertos) {
                    lstChamadosAbertos.getItems().add(chamado.toString());
                }
            }

        } catch (Exception e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Não foi possível listar os chamados: " + e.getMessage());
        }
    }

    private void exibirAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }
}
