package nicolasmneves;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApp extends Application {

    private static Stage stagePrincipal;

    @Override
    public void start(Stage stage) {
        stagePrincipal = stage;
        trocarTela("TelaCadastroUsuario.fxml", "Cadastro de Usuário");
    }

    public static void trocarTela(String fxml, String titulo) {

        try {

            FXMLLoader loader = new FXMLLoader(
                    MainApp.class.getResource(fxml));

            Parent root = loader.load();

            stagePrincipal.setScene(new Scene(root));
            stagePrincipal.setTitle(titulo);
            stagePrincipal.show();
            stagePrincipal.setResizable(false);

        } catch (IOException e) {
            throw new RuntimeException("Erro ao carregar tela " + fxml + ": " + e.getMessage(), e);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}