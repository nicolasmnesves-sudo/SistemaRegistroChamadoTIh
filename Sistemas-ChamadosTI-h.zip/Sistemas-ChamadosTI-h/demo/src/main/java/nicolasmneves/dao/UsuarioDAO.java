package nicolasmneves.dao;

import nicolasmneves.conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioDAO {

    /**
     * Verifica se já existe um usuário cadastrado com esse login.
     */
    public boolean usuarioExiste(String usuario) {

        String sql = "SELECT id FROM usuarios WHERE usuario = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement ps = conexao.prepareStatement(sql)) {

            ps.setString(1, usuario);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (Exception e) {
            throw new RuntimeException("Erro ao verificar usuário: " + e.getMessage(), e);
        }
    }

    /**
     * Cadastra um novo usuário no banco de dados.
     */
    public void cadastrar(String nome, String usuario, String senha) {

        String sql = "INSERT INTO usuarios(nome, usuario, senha) VALUES (?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement ps = conexao.prepareStatement(sql)) {

            ps.setString(1, nome);
            ps.setString(2, usuario);
            ps.setString(3, senha);

            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Erro ao cadastrar usuário: " + e.getMessage(), e);
        }
    }

    /**
     * Verifica se usuário e senha conferem com um registro do banco.
     */
    public boolean autenticar(String usuario, String senha) {

        String sql = "SELECT id FROM usuarios WHERE usuario = ? AND senha = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement ps = conexao.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, senha);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (Exception e) {
            throw new RuntimeException("Erro ao autenticar: " + e.getMessage(), e);
        }
    }
}
