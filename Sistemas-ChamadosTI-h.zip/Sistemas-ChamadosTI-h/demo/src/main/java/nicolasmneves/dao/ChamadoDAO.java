package nicolasmneves.dao;

import nicolasmneves.conexao.Conexao;
import nicolasmneves.model.Chamado;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ChamadoDAO {

    /**
     * Registra um novo chamado de TI no banco de dados.
     * O status_chamado é preenchido automaticamente como "Aberto" pelo próprio banco.
     */
    public void registrar(Chamado chamado) {

        String sql = "INSERT INTO chamados(solicitante, equipamento, problema, prioridade) VALUES (?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement ps = conexao.prepareStatement(sql)) {

            ps.setString(1, chamado.getSolicitante());
            ps.setString(2, chamado.getEquipamento());
            ps.setString(3, chamado.getProblema());
            ps.setString(4, chamado.getPrioridade());

            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Erro ao registrar chamado: " + e.getMessage(), e);
        }
    }

    /**
     * Desafio extra: lista apenas os chamados com status "Aberto".
     */
    public List<Chamado> listarAbertos() {

        String sql = "SELECT * FROM chamados WHERE status_chamado = 'Aberto' ORDER BY data_abertura DESC";

        List<Chamado> lista = new ArrayList<>();

        try (Connection conexao = Conexao.conectar();
             PreparedStatement ps = conexao.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Chamado chamado = new Chamado();
                chamado.setId(rs.getInt("id"));
                chamado.setSolicitante(rs.getString("solicitante"));
                chamado.setEquipamento(rs.getString("equipamento"));
                chamado.setProblema(rs.getString("problema"));
                chamado.setPrioridade(rs.getString("prioridade"));
                chamado.setStatusChamado(rs.getString("status_chamado"));
                chamado.setDataAbertura(String.valueOf(rs.getTimestamp("data_abertura")));
                lista.add(chamado);
            }

        } catch (Exception e) {
            throw new RuntimeException("Erro ao listar chamados abertos: " + e.getMessage(), e);
        }

        return lista;
    }
}
