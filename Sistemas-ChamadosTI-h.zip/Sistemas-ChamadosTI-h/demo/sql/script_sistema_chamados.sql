CREATE DATABASE IF NOT EXISTS sistema_chamados_ti;
USE sistema_chamados_ti;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(50) NOT NULL,
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chamados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    solicitante VARCHAR(100) NOT NULL,
    equipamento VARCHAR(100) NOT NULL,
    problema VARCHAR(255) NOT NULL,
    prioridade VARCHAR(20) NOT NULL,
    status_chamado VARCHAR(30) DEFAULT 'Aberto',
    data_abertura DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Teste obrigatório (rodar depois de cadastrar usuários e chamados pelo sistema)
-- SELECT * FROM usuarios;
-- SELECT * FROM chamados;

-- Desafio extra: listar apenas chamados com status "Aberto"
-- SELECT * FROM chamados WHERE status_chamado = 'Aberto';
